(function() {
  'use strict';

  angular.module('spinner')
    .component('loadingSpinner', {
      templateUrl: 'app/spinner/loadingspinner.template.html',
    });

})();
