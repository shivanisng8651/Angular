(function() {
  'use strict';

  angular.module('spinner', []);

})();
