(function() {
  'use strict';

  angular.module('data')
    .constant('ApiBasePath', "//davids-restaurant.herokuapp.com");

})();
