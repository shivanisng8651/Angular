(function() {
  'use strict';

  angular.module('NarrowItDownApp', []);

})();
