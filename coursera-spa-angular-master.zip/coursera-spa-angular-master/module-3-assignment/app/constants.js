(function() {
  'use strict';

  angular.module('NarrowItDownApp')
    .constant('ApiBasePath', "//davids-restaurant.herokuapp.com");

})();
