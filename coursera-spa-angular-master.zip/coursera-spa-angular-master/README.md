# Single Page Web Applications with AngularJS

Repo for course: https://www.coursera.org/learn/single-page-web-apps-with-angularjs

Repo Web Site: https://robertosequeira.github.io/coursera-spa-angular/


## Example course files

https://github.com/jhu-ep-coursera/fullstack-course5
